from django.shortcuts import render
from pagina.models import Post

# Create your views here.

def home(request):
    return render(request, 'layout_home.html')

def post(request, post_id):
    post = Post.objects.get(pk=post_id)
    return render (request, 'layout_post.html', {'post': post})
